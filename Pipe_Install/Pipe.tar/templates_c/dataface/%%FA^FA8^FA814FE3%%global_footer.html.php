<?php /* Smarty version 2.6.18, created on 2015-05-23 05:35:21
         compiled from global_footer.html */ ?>
