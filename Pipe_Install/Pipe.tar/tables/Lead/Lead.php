<?php
class tables_Lead {
	
	function getTitle(&$record){
		return $record->val('clientName'). ' ' . $record->val('clientSurname')  ;
	}


}
?>
