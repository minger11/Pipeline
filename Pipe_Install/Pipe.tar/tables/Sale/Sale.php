<?php
class tables_Sale {
	
	function getTitle(&$record){
	return 'Sale Record';
	}

	   		 
}

?>







