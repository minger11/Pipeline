<?php



class tables_Partner {
	
	function getTitle(&$record){
		return $record->val('partnerName'). ' ' . $record->val('partnerSurname')  ;
	}


}
?>
