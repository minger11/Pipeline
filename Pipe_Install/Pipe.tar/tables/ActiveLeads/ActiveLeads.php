<?php
class tables_ActiveLeads {
	
	function getTitle(&$record){
		return $record->val('leadName'). ' ' . $record->val('leadSurname')  ;
	}


}
?>
