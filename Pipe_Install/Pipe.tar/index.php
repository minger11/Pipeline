<?php //Main Application access point

if ( !isset($_REQUEST['-sort']) and @$_REQUEST['-table'] == 'Partner' ){
    $_REQUEST['-sort'] = $_GET['-sort'] = 'partnerName';}

if ( !isset($_REQUEST['-sort']) and @$_REQUEST['-table'] == 'Lead' ){
    $_REQUEST['-sort'] = $_GET['-sort'] = 'clientSurname asc';}

if ( !isset($_REQUEST['-sort']) and @$_REQUEST['-table'] == 'Sale' ){
    $_REQUEST['-sort'] = $_GET['-sort'] = 'clientSurname asc';}



require_once "/opt/lampp/htdocs/xataface/public-api.php";
df_init(__FILE__, "/xataface")->display();
